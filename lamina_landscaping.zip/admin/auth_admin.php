<?php
require_once __DIR__ . '/../includes/auth_middleware.php';
require_admin();
?>